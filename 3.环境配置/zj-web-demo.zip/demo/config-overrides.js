/**
 * @Title: config-overrides
 * @ProjectName pool-web
 * @Description: TODO
 * @author fuxiang_dai
 * @date 2018/8/6  10:14
 */
const {injectBabelPlugin} = require('react-app-rewired');
const theme = require('./theme');
const rewireLess = require('react-app-rewire-less');
module.exports = function override(config, env) {
    config = injectBabelPlugin(['import', {libraryName: 'antd', style: true}], config);
    config = rewireLess.withLoaderOptions({
        javascriptEnabled: true,
        modifyVars: theme
    })(config, env);
    return config;
};