import {apiConfig} from "./api.config";
import agent from 'superagent';
export const getAjaxPost = (url,data,callback) => {
   // console.log("dara",data)
    agent.post(url).type('form')
        .send(data)
        .end((err, res) => { // end函数体
          //  console.log('res', res);
            /* err为空：请求成功；不为空：请求错误(这时res.body也为空)；也可通过直接判断res.ok===true或res.status===200进行处理；*/

            if( res!==undefined&&res.body!=undefined&&res.body!=null){
               // console.log('res', res.body);
                callback(res.body)
            }

        });
};
export const getAjaxGet=(url,data,callback)=>{

    agent.get(url)
        .query(data)
        .end((err, res) => { // end函数体
            // console.log('res', res);

            if(res.body!=undefined&&res.body!=null&&res.body.status!=undefined){
            //    console.log('res', res.body);
                callback(res.body)
            }

        });
}
export  const CheckExcel=(value,callback)=>{//获取组织机构
    getAjaxGet(apiConfig.demo.export_check,value,(e)=>{
        callback(e)
    })
}
export  const getOrganization=(callback)=>{//获取组织机构
    let data={}
    getAjaxGet(apiConfig.demo.organization_all,data,(e)=>{
        callback(e)
    })
}
export  const getRegion=(callback)=>{//获取行政区域
    let data={}
    getAjaxGet(apiConfig.demo.region_all,data,(e)=>{
        callback(e)
    })
}
export  const getTaxTree=(callback)=>{//获取税种
    let data={}
    getAjaxGet(apiConfig.demo.tax_info_all,data,(e)=>{
        callback(e)
    })
}
export  const getTaxRate=(code,callback)=>{//获取税率
    let data=
        {
            "pageInfo.page":1,
            "pageInfo.rows":100,
            "taxCode":code,
        }
    getAjaxGet(apiConfig.demo.tax_rate_all,data,(e)=>{
        callback(e)
    })
}
export  const getTaxCode=(callback)=> {//获取税码
    let data =
        {
            "pageInfo.page": 1,
            "pageInfo.rows": 100,
        }
    getAjaxGet(apiConfig.demo.tax_code_all, data, (e) => {
        callback(e)
    })
}
export  const getVirTualTax=(callback)=> {//获取虚拟税号
    let data =
        {
            "page":1,
            "rows":100,
        }
    getAjaxGet(apiConfig.demo.virtual_tax_all, data, (e) => {
        callback(e)
    })
}
export  const getinvoiceType=(callback)=> {//获取发票类型
    let data =
        {
            "pageInfo.page": 1,
            "pageInfo.rows": 100,
        }
    getAjaxGet(apiConfig.demo.invoice_type_all, data, (e) => {
        callback(e)
    })
}
export  const getbusinessRange=(code,callback)=>{//获取业务范围
    let data=
        {
            "pageInfo.page":1,
            "pageInfo.rows":100,
            "companyCode":code,
        }
    getAjaxGet(apiConfig.demo.business_range_all,data,(e)=>{
        callback(e)
    })
}
export  const getPeriodsDatas=(code,callback)=>{//获取期数
    let data=
        {
            "pageInfo.page":1,
            "pageInfo.rows":100,
            "companyCode":code,
        }
    getAjaxGet(apiConfig.demo.propertyPriceDeclaration_all,data,(e)=>{
        callback(e)
    })
}
export  const getBusinessPeriodsDatas=(callback)=>{//获取企业所得税,期数
    let data=
        {
            "pageInfo.page":1,
            "pageInfo.rows":100,
        }
    getAjaxGet(apiConfig.demo.businessIncomeDeclaration_all,data,(e)=>{
        callback(e)
    })
}
export  const getDeclarationMethod=(callback)=>{//获取申报方式
    let data=
        {
            "pageInfo.page":1,
            "pageInfo.rows":100,
            "quickSearchValue":'',
        }
    getAjaxGet(apiConfig.demo.declaration_method_all,data,(e)=>{
        callback(e)
    })
}
export  const getDeclarationTemplate=(code,callback)=>{//获取申报模板
    let data=
        {
            "pageInfo.page":1,
            "pageInfo.rows":100,
            "companyCode":code,
        }
    getAjaxGet(apiConfig.demo.companyDeclarationTemplate_all,data,(e)=>{
        callback(e)
    })
}
export  const getAssetsData=(callback)=>{//获取房产申报类型
    let data=
        {
            "pageInfo.page":1,
            "pageInfo.rows":100,
            "quickSearchValue":'',
        }
    getAjaxGet(apiConfig.demo.houseAssetsDeclaration_all,data,(e)=>{
        callback(e)
    })
}
/*   获取树结构数据*/
export  const getcompanyInfoData=(callback)=>{//获取公司信息
    let data={}
    getAjaxGet(apiConfig.demo.company_info_all,data,(e)=>{
        callback(e)
    })
}
export  const getIndustryTypeData=(callback)=>{//获取所属行业
    let data={}
    getAjaxGet(apiConfig.demo.industry_type_all,data,(e)=>{
        callback(e)
    })
}
export  const getBusinessRegData=(callback)=>{//获取业务范围
    let data={
        "page":1,
        "rows":100,
        "quickSearchValue":'',
    }
    getAjaxGet(apiConfig.demo.business_reg_type_all,data,(e)=>{
        callback(e)
    })
}
export  const getAccountData=(callback)=>{//获取核算账套
   let data= {
       "page":1,
       "rows":100,
    }
    getAjaxGet(apiConfig.demo.accounting_set_all,data,(e)=>{
        callback(e)
    })
}
export  const getTaxAuthorityData=(callback)=>{//获取税务机关
    let data={
        "page":1,
        "rows":100,
        "quickSearchValue":'',
    }
    getAjaxGet(apiConfig.demo.tax_authority_all,data,(e)=>{
        callback(e)
    })
};
export  const getMainTaxAuthority=(code,callback)=>{//获取主管税务机关
    let data={
        "pageInfo.page":1,
        "pageInfo.rows":100,
        "companyCode":code,
    }
    getAjaxPost(apiConfig.demo.company_detail_all_tax,data,(e)=>{
        callback(e)
    })
};
/*   获取申报抬头要素数据*/
export  const getdeclarationElementData=(callback)=>{
    let data={
        page:1,
        rows:100,
        keywords:'',
    }
    getAjaxGet(apiConfig.demo.declaration_element_all,data,(e)=>{
        callback(e)
    })
}
/*   获取法人数据*/
export  const getLegalPersonData=(callback)=>{//法人
    let data={
        page:1,
        rows:100,
        keywords:'',
    }
    getAjaxGet(apiConfig.demo.legal_person_all,data,(e)=>{
        callback(e)
    })
}
/*   获取系统配置版本数据*/
export  const getDelVersionData=(callback)=>{//版本
    let data={
        "pageInfo.page":1,
        "pageInfo.rows":100,
    }
    getAjaxGet(apiConfig.demo.declarationTemplateVersion_all,data,(e)=>{
        callback(e)
    })
}
export  const getstampTaxRange=(callback)=>{//获取印花税征税范围
    let data={
        "page":1,
        "rows":100,
        "quickSearchValue":'',
    }
    getAjaxGet(apiConfig.demo.StampTaxRange_all,data,(e)=>{
        callback(e)
    })
};
export  const gettaxReduction=(callback)=>{//获取减免税
    let data={
        "page":1,
        "rows":100,
        "quickSearchValue":'',
    }
    getAjaxGet(apiConfig.demo.tax_relief_type_all,data,(e)=>{
        callback(e)
    })
}
export  const getlandAcquisitionMethodData=(callback)=>{//获取土地取得方式
    let data={
        "page":1,
        "rows":100,
        "quickSearchValue":'',
    }
    getAjaxGet(apiConfig.demo.landAcquisitionMethod_all,data,(e)=>{
        callback(e)
    })
};
export  const getlandUseData=(callback)=>{//获取土地房屋用途
    let data={
        "page":1,
        "rows":100,
        "quickSearchValue":'',
    }
    getAjaxGet(apiConfig.demo.landHousePurpose_all,data,(e)=>{
        callback(e)
    })
};
export  const getHouseData=(callback)=>{//获取房屋资产数据
    let data={
        "page":1,
        "rows":100,
        "quickSearchValue":'',
    }
    getAjaxGet(apiConfig.demo.houseAssets_get,data,(e)=>{
        callback(e)
    })
};

export  const getLevyScope=(callback)=>{//获取土地要素配置的征税范围
    let data={
        "page":1,
        "rows":100,
        "quickSearchValue":'',
    }
    getAjaxGet(apiConfig.demo.landAssetsElement_all,data,(e)=>{
        callback(e)
    })
};
export  const getLandAssetsElementData=(key, callback)=>{//获取土地要素配置数据
    let data={
        "page":1,
        "rows":100,
        "levyScope":key,
    }
    getAjaxGet(apiConfig.demo.landAssetsElement_all,data,(e)=>{
        callback(e)
    })
};
export  const getTaxSourceCode=(code,callback)=>{//查水资源税主数据（税源编号）
    let data=
        {
            "pageInfo.page":1,
            "pageInfo.rows":100,
            "companyCode":code,
        }
    getAjaxGet(apiConfig.demo.waterResourceTax_com,data,(e)=>{
        callback(e)
    })
}

export  const  TreeCheck=(rule,value,callback)=>{//验证树结构是否被选择
 // console.log(value)
    if(value===undefined||value.value===''||value.key===''||value.value==='undefined'||value.key==='undefined'||value===''){
        callback("请选择")
       // if(value.key!===undefined)
      //  console.log("进入:,",value)
    }
    else{
        callback()
    }
}
export  const  isNull=(value)=>{//undefined转义为null
    let data='';
    if(value===undefined||value===null||value==''){
        data=0
    }
    else{
        data=value
    }
    return  data
}
export  const  DateSub=(value)=>{//时间截图2018-11-11 00:00:00
    let data='';
    if(value===undefined||value===null||value==''){
        data=''
    }
    else{
        data=value.substring(0,10)
    }
    return  data
}

export  const  isDouble=(value)=>{//保留小数点2位
   // var re = /([0-9]+\.[0-9]{2})[0-9]*/;
   // aNew = a.replace(re,"$1");
}
export  const TimeData=(d)=>{//转化时间戳
   let  str = d.replace(/-/g,'/');
         let date = new Date(str);

        return     date.getTime()/1000
}
export  const timeFunc=(n)=>{//n为距离现在几天,0代表今天,1代表昨天

    var n = n;
    var d = new Date();
    var year = d.getFullYear();
    var mon = d.getMonth() + 1;
    var day = d.getDate();
    if(day <= n) {
        if(mon > 1) {
            mon = mon - 1;
        } else {
            year = year - 1;
            mon = 12;
        }
    }
    d.setDate(d.getDate() - n);
    year = d.getFullYear();
    mon = d.getMonth() + 1;
    day = d.getDate();
    let   s = year + "-" + (mon < 10 ? ('0' + mon) : mon) + "-" + (day < 10 ? ('0' + day) : day);
    //console.log(s)
    return s;

}