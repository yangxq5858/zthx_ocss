/* API接口应用代理路径 */

export const EUI_API=JSON.parse(window.atob(localStorage.getItem('EUI_API')))
/*export const EUI_API= {
    Server_URL: '/fms_tax_web.api/',
    EUI_STYLE:'http://10.4.208.85/EUI/blue/eui.unmin.css',//eui样式文件
    BASIC_IP:'http://10.4.208.85',////ecmp平台基地址
    CONTRACT_BASIC:'http://10.4.208.85:83/fms_tax_web.api/',
    PATH_URL:'',
   /!* PATH_URL:'http://10.4.208.85:83/fms-tax-web/',*!/
};*/
