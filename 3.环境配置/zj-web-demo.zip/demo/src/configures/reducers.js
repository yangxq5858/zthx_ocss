import {combineReducers} from 'redux';
/* 将整个应用的Reducer合并为一个Reducer */
export const reducers = combineReducers({




});

