import React from 'react';
import {Provider} from 'react-redux';
import {hashHistory, Route, Router} from 'react-router';
import {store} from './store';
import CompanyInfo from '../components/DataDisplay/BaseData/company-info/company-info-view';
import  WaterResourceTax  from  "../components/DataDisplay/WaterResourceTax/water-resource-tax/water-resource-tax-view"
/* 路由整个应用的组件模块 */
export default class Routers extends React.Component {
    render() {
        return (
            <Provider store={store}>
                <Router history={hashHistory}>
                    <Route exact path="/" component={CompanyInfo}/>
                    <Route path={`companyInfo`} component={CompanyInfo}/>
                    <Route path={`WaterResourceTax`} component={WaterResourceTax}/>
                </Router>
            </Provider>
        );
    }
}
