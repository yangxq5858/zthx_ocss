/**
 * g公司和公司明细
 */
import React from 'react';
import { Col, Checkbox, Row,Table,Icon,Input,Tree,Divider,Modal,Spin,message,Button} from 'antd';
import './company-info-style.css';
import AddComapnyForm from './company-add-form'
import AddTaxRateForm from './company-detail-add-form'
import {apiConfig} from "../../../../configures/api.config";
import {getAjaxPost,getAjaxGet} from  '../../../../configures/commen.js'
import  CompanyDetail from  "./company-detail-table"
const Search = Input.Search;
const TreeNode=Tree.TreeNode
const confirm = Modal.confirm;
const delId=[];
export default class TaxInfo extends React.Component {
    state = {
         checkId:undefined,
         checkName:'长虹集团',
         showModal:false,
         showLevel:false,
         modalTitle:'',
         TreeDatas: [],
        delTaxId:[],//删除选择的税种
        visibleDelModal:false,
        companyInforformData:{companyCode:'',companyName:'',frozen:false,id:'',level:'',companyType:''},//新增节点form表单默认数据
        taxRateformData:{rateCode:'',taxRate:'',frozen:false,taxRateDefault:true,id:''},//新增税率form表单默认数据
        taxType:0,//税收类型
        formTitle:["税种代码","税种名称","冻结"],
        modalType:0,//0新增1编辑
        visibleAddTaxRate:false,
        pageNum:1,
        pageSize:5,
        isLoading:false,
        editData:{
            frozen:false,
            companyName:'',
            level:'',
            companyType:'',
            companyCode:'',
            id:''
        },
        leftData:[],
        dataSource:[],//税率列表
        records:0,//总条数
        parentId:'',
        creatParent:false,//是否创建根节点
        columns: [
           {title: '序号', width: 50, dataIndex: 'key', key: 'key',align:'center',
                render: (text,record,index) => (
                    <span>
                        {(this.state.pageNum-1)*this.state.pageSize+index+1}
                    </span>
                )},
            {title: '公司代码', dataIndex: 'companyCode', key: 'companyCode',align:'center'},
            {title: '公司名称',dataIndex: 'companyName', key: 'companyName',align:'center',
                render: (text, record) => (
                    <span>
                     <a href="javascript:;" onClick={this.doDetail.bind(this,record)}>{text}</a>
                    </span>
                )},
            {title: '层级代码',dataIndex: 'level', key: 'level',align:'center'},
            {
                title: '公司类型', dataIndex: 'companyType', key: 'companyType', align: 'center',
            },
            {
                title: '冻结',
                width: 50,
                dataIndex: 'frozen',
                key: 'frozen',
                align:'center',
                render: (text, record) => (
                    <Checkbox checked={text} disabled />
                )}
        ],
        dataSourceCompanyDetail: [],
        dataComanyHeader:[],//点击抬头获取的信息
        disPlay:false,
    };
    /*新增根节点*/
    addTreeParen=(e)=>{
      this.setState({
          showModal:true,
          modalType:0,
          creatParent:true,
          companyInforformData:{companyCode:'',companyName:'',frozen:false,id:'',level:'',companyType:''},//新增节点form表单默认数据
          modalTitle:'根节点'
      })
    }
 /*  新增树节点*/
    addTreeNode=(e)=>{
        console.log(this.state.checkId)
        if(this.state.checkId===undefined){
            message.warning("请选择父节点");
            return
        }
        this.setState({
         showModal:true,
         modalType:0,
         creatParent:false,
         companyInforformData:{companyCode:'',companyName:'',frozen:false,id:'',level:'',companyType:''},//新增节点form表单默认数据
         modalTitle:this.state.checkName+"子类"
       })
    }
    /*点击选择数节点*/
    selectTreeNode=(e,value)=>{
        console.log("e",e,value.node.props.children)
      /*  构造左边公司抬头数据*/
        let leftData=[];
        let chdata=value.node.props.children
           leftData=[
                { frozen:value.node.props.frozen,
                    companyName:value.node.props.title,
                    level:value.node.props.level,
                    companyType:value.node.props.companyType,
                    companyCode:value.node.props.companyCode==0?'':value.node.props.companyCode,
                    id:e[0],
                    parentId:value.node.props.parentId
                }
            ]
        if(chdata!=undefined&&chdata.length>0){
            chdata.forEach(function(item,index){
                leftData.push(
                 { frozen:item.props.frozen,
                    companyName:item.props.title,
                    level:item.props.level,
                    companyType:item.props.companyType,
                    companyCode:item.props.companyCode==0?'':item.props.companyCode,
                    id:e[0],
                     parentId:item.props.parentId
                }
               )
            })
        }
        let that=this;
        delId.length=0;
        delId.push(e[0])
        let val=value.node.props.children
        if(val!==undefined){
         val.forEach(function(item,index){
            delId.push(item.key)
          return  that.getLoopId(item.props.children)
         })
        }
        this.setState({
            disPlay:false,
            checkId:e[0],
            checkName:value.node.props.title,
            parentId:value.node.props.parentId,
            editData:{
                frozen:value.node.props.frozen,
                companyName:value.node.props.title,
                level:value.node.props.level,
                companyType:value.node.props.companyType,
                companyCode:value.node.props.companyCode==0?'':value.node.props.companyCode,
                id:e,
            },
            pageNum:1,
            pageSize:5,
            leftData:leftData,

        })
         /* setTimeout(() => {
                this.getTaxRate()
           },0);//通过延时处理*/

    }
    getLoopId=(val)=>{
         let that=this;
        if(val!==undefined){
          val.forEach(function(item,index){
            if(item.props.children!=undefined){
                 that.getLoopId(item.props.children);
            }
            delId.push(item.key)
            return item.key
         })
      }
    }
    doDetail=(e)=>{
       console.log(e)
        this.setState({
            dataComanyHeader:e,
            disPlay:true,
        })
        setTimeout(() => {
            this.getCompanyDetail();
        },0);//通过延时处理

    }
    getCompanyDetail=(e)=>{
        this.setState({
            isLoading:true,
        })
        let data={
            companyCode:this.state.dataComanyHeader.companyCode
        }
        getAjaxGet(apiConfig.demo.company_detail_all,data,(e)=>{
            console.log("e,",e);
            if(e.status===200){
                console.log(e.data)
                this.setState({
                    isLoading:false,
                    dataSourceCompanyDetail:e.data,
                })
            }
            else{
                this.setState({
                    isLoading:false,
                })
                message.error(e.message)
            }
        })
    }
   /* 编辑节点*/
   editTreeNode=(e)=>{

       if(this.state.checkId===undefined||this.state.checkId==0){
            message.warning("请选择一个节点");
            return
        }
        /* let companyInforformData={companyCode:this.state.editData.code,companyName:this.state.checkName,frozen:this.state.editData.frozen,id:this.state.checkId}
        */
        this.setState({
             modalType:1,
             companyInforformData:this.state.editData,
             showModal:true,
         })
    }
  /*  删除树节点*/
    deleteTreeNode=(e)=>{
        if(this.state.checkId===undefined||this.state.checkId==0){
            message.warning("请选择长虹集团下面一个子节点");
            return
        }
        let checkname=this.state.checkName
          let that=this;
        confirm({
            title: '是否确定删除该的节点以及其子节点?',
            content: '',
            okText: '是',
            okType: 'danger',
            cancelText: '否',
            onOk() {
                let data={id:delId.toString()};
                getAjaxPost(apiConfig.demo.company_info_del,data,(e)=>{
                  if(e.status===200){
                      message.success("删除成功")
                      that.setState({
                        btnLoading:false,
                        visibleDelModal:false
                    })
                      setTimeout(() => {
                          that.getData();
                      },0);//通过延时处理
                  }
                  else{
                    that.setState({
                        btnLoading:false
                    })
                      message.error(e.message)
                  }
                })
            },
            onCancel() {
                console.log('Cancel');
            },
        });
    }

    /*取消新增编辑税率弹出框*/
    handleCancelTaxRate=(e)=>{
        this.setState({
            visibleAddTaxRate:false,
        })
    }
   handleCancel=(e)=>{
           this.setState({
            showModal:false
           })
   }
    componentDidMount(){
        //this.props.loadSelectTypeTreeData();
        this.getData()
    }
    /* 提交数据*/
    submitForm=(values)=>{
        this.setState({
            btnloading:true,
        })
     //   console.log(`提交的数据${values}`,values,this.state.creatParent);
        let data={
            companyCode:values.companyCode,
            companyName:values.companyName,
            companyType:values.companyType,
            level:values.level,
            frozen:values.frozen,
            parentId:this.state.creatParent?'':this.state.checkId,
            id:values.id
        }
        if(this.state.modalType===0){
            this.addTree(data)
        }
        else{
            this.editTree(data)
        }
    }
    addTree=(values)=>{
        delete values.id;
        getAjaxPost(apiConfig.demo.company_info_add,values,(e)=>{
            this.setState({
                btnloading:false,
            })
            if(e.status===200){
                message.success("操作成功");
                this.setState({
                    showModal:false
                })
                this.getData();
            } else{
                message.error(e.message)
            }
        })
    }
    editTree=(values)=>{
        delete values.parentId;
        getAjaxPost(apiConfig.demo.company_info_edit,values,(e)=>{
            this.setState({
                btnloading:false,
            })
            if(e.status===200){
                message.success("操作成功");
                this.setState({
                    showModal:false
                })
                this.getData();
            } else{
                message.error(e.message)
            }
        })
    }
 /*   获取树结构数据*/
   getData=()=>{
        this.setState({
            isLoading:true,
        })
        let data={
        }
        getAjaxGet(apiConfig.demo.company_info_all_all,data,(e)=>{
          console.log("e,",e);
          if(e.status===200){
              console.log(e.data)
              this.setState({
                  isLoading:false,
                  TreeDatas:e.data,
              })
          }
          else{
              this.setState({
                  isLoading:false,
              });
              message.error(e.message)
          }
        })
    }


   /* 公司明细*/
  /* 新增公司*/
  submitFormTaxRate=(values)=>{
    if(this.state.modalType===0){
            this.addTaxRateForm(values)
        }
        else{
            this.editTaxRate(values)
        }
  }

    render() {
      const {dataComanyHeader,dataSourceCompanyDetail,disPlay,editData,leftData,records,dataSource,pageSize,pageNum,showModal,modalTitle,checkName,companyInforformData,formTitle,modalType,columns,taxRateformData,visibleAddTaxRate,TreeDatas,isLoading}=this.state;
      const loop=data=>data.map(function(item,index){
          if (item.childrenList && item.childrenList.length) {
           return <TreeNode icon={<Icon type="folder" />} companyCode={item.companyCode} level={item.level} companyType={item.companyType} frozen={item.frozen} key={item.id}  title={item.companyName} parentId={item.parentId}>{loop(item.childrenList)}</TreeNode>;
          }
            else{
               return <TreeNode icon={<Icon type="file-text" />}  companyCode={item.companyCode} level={item.level} companyType={item.companyType} frozen={item.frozen} key={item.id} parentId={item.parentId} title={item.companyName}/>
           }

       })
        return (
            <div>
                <Spin spinning={false}>
                <Row type="flex">

                <Col span={24} className={disPlay===false?"select_type_header select_type_header1":"select_type_header"}>
                <span className="title">公司</span></Col>
                    <Col span={10} >
                      <div className="operas_div">
                          <a href="javascript:" className="a_btn" onClick={this.addTreeParen}><Icon type="plus" />&nbsp;创建根节点</a>
                         <a href="javascript:" className="a_btn" onClick={this.addTreeNode}><Icon type="plus" />&nbsp;创建节点</a>
                         <a href="javascript:" className="a_btn" onClick={this.editTreeNode}><Icon type="edit" />&nbsp;编辑</a>
                         <a href="javascript:" className="a_btn" onClick={this.deleteTreeNode}><Icon type="close" />&nbsp;删除</a>

                       {/* <Search
                         placeholder="请输入关键字查询"
                         onSearch={this.searchHandel}
                         style={{ width: 200 }}
                         />*/}
                       </div>
                       <div className="tree_show_list" >
                           {TreeDatas!==null&&<Tree
                            showIcon
                            autoExpandParent={true}
                            onSelect={this.selectTreeNode}
                            defaultExpandAll
                            defaultSelectedKeys={['-1']}
                          >
                           {loop(TreeDatas)}
                          </Tree>}
                       </div>
                    </Col>
                    <Col span={14} className="create_select_type_company">
                        <div className="tax-rate-title">
                            <span>{checkName}公司抬头</span>
                        </div>
                        <Table
                            bordered
                            columns={columns}
                            dataSource={leftData}
                            size="small"
                            loading={isLoading}
                            pagination={{//根据ant中pagination组件可以添加相应的参数,此处只简单进行处理
                                pageSize:5,
                            }}
                        />
                    </Col>
                    {disPlay&&<CompanyDetail
                        display_name="none"
                        getData={this.getCompanyDetail}
                        dataComanyHeader={dataComanyHeader} dataSource={dataSourceCompanyDetail}/>}
                </Row>
                    <Modal
                        visible={showModal}
                        footer={null}
                        maskClosable={false}
                        onCancel={this.handleCancel}
                        title={`${modalType===0?'新增':'编辑'}${modalTitle}`}
                        width={800}
                        className="del-tax-modal"
                    >
                        {showModal&&<AddComapnyForm btnloading={this.state.btnloading} type={modalType} formData={companyInforformData} formTitle={formTitle} checkDataType={this.checkDataType} callback={this.submitForm}/>}
                    </Modal>
                </Spin>
            </div>

        );
    }
}
