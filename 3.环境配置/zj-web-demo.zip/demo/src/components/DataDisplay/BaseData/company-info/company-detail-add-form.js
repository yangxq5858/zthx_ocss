/**
 * Created by hutao on 2017/4/16.
 */
import React from 'react';
import { Form, Icon, Input, Button, Radio,Select,Row,Col,TreeSelect,DatePicker } from 'antd';
import "./company-info-style.css"
import moment from 'moment';
import {
    getIndustryTypeData,
    getBusinessRegData,
    getTaxAuthorityData,
    TreeCheck
} from "../../../../configures/commen"
const FormItem = Form.Item;
const Option = Select.Option;
const RadioGroup = Radio.Group;
const dateFormat = 'YYYY-MM-DD'
const {  RangePicker } = DatePicker;
const TreeNode = TreeSelect.TreeNode;
class BaseDataForm extends React.Component {
    constructor(props) {
        super(props)
    }
    state={
        industryData:[],
        businessData:[],
        taxAuthority:[],

        regionTree:[]
    }
    componentDidMount(){
        getIndustryTypeData(e=>{
            if(e.status===200){
                this.setState({
                    industryData:e.data,
                })
            }
        })
        getBusinessRegData(e=>{
            if(e.status===200){
                this.setState({
                    businessData: e.data.rows,
                })
            }
        })
        getTaxAuthorityData(e=>{
            if(e.status===200){
                this.setState({
                    taxAuthority: e.data.rows,
                })
            }
        })


    }
    handleSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFields((err, fieldsValue) => {
            if(!err){
                const rangeValue = fieldsValue['time'];
                const values = {
                    ...fieldsValue,
                    'startTime': rangeValue[0].format('YYYY-MM-DD'),
                    'endTime': rangeValue[1].format('YYYY-MM-DD'),
                    'time':[]

                }
                this.props.callback(values)
            }
        });
    };
    handleChange=(e)=>{
        console.log(e)
    }

    render() {
        const {industryData,businessData,taxAuthority,legalPerson}=this.state;
      //  console.log(this.state.industryData,"ddddddddddd")
        const { getFieldDecorator } = this.props.form;
        const {formData,checkDataType,type} =this.props;
        const formItemLayout = {
            labelCol: {
                xs: { span: 15},
                sm: { span: 15},
            },
            wrapperCol: {
                xs: { span: 20 },
                sm: { span: 20 },
            },
        };
        const formItemBtn = {
            labelCol: {
                xs: { span:24 },
                sm: { span: 24 },
            },
        };
        const loop=data=>data.map(function(item){
            if (item.childrenList && item.childrenList.length) {
                return <TreeNode disabled={item.frozen} icon={<Icon type="folder" />} key={item.code} value={item.code} title={item.name}>{loop(item.childrenList)}</TreeNode>;
            }
            else{
                return <TreeNode disabled={item.frozen} icon={<Icon type="file-text" />}  value={item.code} title={item.name} key={item.code}/>
            }

        })

        // let show=this.state
        return (
            <div className="company-detail-add-form">

                <Form onSubmit={this.handleSubmit}  className="div-from company-detail-form"
                >
                    <FormItem
                        label={''}
                    >
                        {getFieldDecorator('id', {
                            initialValue:formData.id,
                        })(
                            <Input type="hidden"/>
                        )}
                    </FormItem>
                    <Row>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'公司代码'}
                        >
                            {getFieldDecorator('companyCode', {
                                initialValue:formData.companyCode,
                            })(
                                <Input disabled={true} />
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'公司名称'}
                        >
                            {getFieldDecorator('companyName', {
                                initialValue:formData.companyName,
                            })(
                                <Input

                                />
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'简称'}
                        >
                            {getFieldDecorator('companySimpleName', {
                                initialValue:formData.companySimpleName,
                            })(
                                <Input
                                />
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'所属行业'}
                        >
                            {getFieldDecorator('industryInvolved', {
                                rules: [ {
                                    required: true, message: '请选择所属行业',
                                    validator:TreeCheck
                                }],
                                initialValue:{value:formData.industryInvolvedCode,label:formData.industryInvolvedName}
                            })(
                                <TreeSelect
                                    labelInValue

                                    dropdownStyle={{ maxHeight: 300, overflow: 'auto' }}
                                    placeholder="请选择"
                                    allowClear={false}
                                    treeDefaultExpandAll
                                >
                                    {industryData!==null?loop(industryData):
                                        <TreeNode  disabled={true} icon={<Icon type="file-text" />}  value={0} title={'Not Found'} key={1}/>
                                    }
                                </TreeSelect>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'注册类型'}
                        >
                            {getFieldDecorator('businessRegType', {
                                rules: [  {
                                    required: true, message: '请选择注册类型',
                                    validator:TreeCheck
                                }],
                                initialValue:formData.businessRegType,

                            })(
                                <Select >
                                    {businessData.length!==0&&businessData.map(function (item,index) {
                                        return <Option value={item.name} key={index}>{item.name}</Option>
                                    })}
                                </Select>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'经济性质'}
                        >
                            {getFieldDecorator('economicNature', {
                                initialValue:formData.economicNature,

                            })(
                                <Select >
                                    <Option value="国有" >国有</Option>
                                    <Option value="集体" >集体</Option>
                                    <Option value="私营" >私营</Option>
                                    <Option value="个体" >个体</Option>
                                    <Option value="股份制" >股份制</Option>
                                    <Option value="外商投资和外国企业" >外商投资和外国企业</Option>
                                </Select>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'所在地'}
                        >
                            {getFieldDecorator('province', {
                                initialValue:formData.province,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'所在地(区县)'}
                        >
                            {getFieldDecorator('county', {
                                initialValue:formData.county,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'注册地'}
                        >
                            {getFieldDecorator('regCity', {
                                initialValue:formData.regCity,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'国税主管机关'}
                        >
                            {getFieldDecorator('stateTaxAuthorities', {
                                initialValue:formData.stateTaxAuthorities,
                                rules: [ {
                                    required: true, message: '请选择国税主管机关',
                                    validator:TreeCheck
                                }],
                            })(
                                <Select>
                                    {taxAuthority.length!==0&&taxAuthority.map(function (item,index) {
                                        return <Option value={item.name} key={index}>{item.name}</Option>
                                    })}
                                </Select>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'地税主管机关'}
                        >
                            {getFieldDecorator('localTaxAuthorities', {
                                initialValue:formData.localTaxAuthorities,
                                rules: [ {
                                    required: true, message: '请选择地税主管机关',
                                    validator:TreeCheck
                                }],
                            })(
                                <Select>
                                    {taxAuthority.length!==0&&taxAuthority.map(function (item,index) {
                                        return <Option value={item.name} key={index}>{item.name}</Option>
                                    })}
                                </Select>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'统一社会信用代码'}
                        >
                            {getFieldDecorator('socialCreditCode', {
                                rules: [  { whitespace: true,message: `请输入统一社会信用代码`},{
                                    required: true, message: `请输入统一社会信用代码`,
                                }],
                                initialValue:formData.socialCreditCode,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'有效时间'}
                        >
                            {getFieldDecorator('time', {
                                initialValue:[moment(formData.startTime, dateFormat), moment(formData.endTime, dateFormat)]
                            })(
                                <RangePicker  allowClear={false}/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'法人'}
                        >
                            {getFieldDecorator('legalPerson', {
                                rules: [  { whitespace: true,message: `请输入法人`},{
                                    required: true, message: `请输入法人`,
                                    validator:TreeCheck
                                }],
                                initialValue:formData.legalPerson,
                            })(
                                <Input />

                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'开户银行'}
                        >
                            {getFieldDecorator('bank', {
                                rules: [  { whitespace: true,message: `请输入开户银行`},{
                                    required: true, message: `请输入开户银行`,
                                }],
                                initialValue:formData.bank,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'开户账号'}
                        >
                            {getFieldDecorator('bankNumber', {
                                rules: [  { whitespace: true,message: `请输入开户账号`},{
                                    required: true, message: `请输入开户账号`,
                                }],
                                initialValue:formData.bankNumber,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'联系电话'}
                        >
                            {getFieldDecorator('telNumber', {
                                initialValue:formData.telNumber,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'备注'}
                        >
                            {getFieldDecorator('remark', {
                                initialValue:formData.remark,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayout}
                                label={'国税财政预算级次'}
                            >
                                {getFieldDecorator('nationalTaxBudget', {
                                    initialValue:formData.nationalTaxBudget,
                                })(
                                    <Select >
                                        <Option value="中央" >中央</Option>
                                        <Option value="省" >省</Option>
                                        <Option value="地级市" >地级市</Option>
                                        <Option value="区县" >区县</Option>
                                    </Select>
                                )}
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayout}
                                label={'国税财政预算级次名称'}
                            >
                                {getFieldDecorator('nationalTaxBudgetName', {
                                    initialValue:formData.nationalTaxBudgetName,
                                })(
                                    <Input/>
                                )}
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayout}
                                label={'地税财政预算级次'}
                            >
                                {getFieldDecorator('localTaxBudget', {
                                    initialValue:formData.localTaxBudget,
                                })(
                                    <Select >
                                        <Option value="中央" >中央</Option>
                                        <Option value="省" >省</Option>
                                        <Option value="地级市" >地级市</Option>
                                        <Option value="区县" >区县</Option>
                                    </Select>
                                )}
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayout}
                                label={"地税财政预算级次名称"}
                            >
                                {getFieldDecorator('localTaxBudgetName', {
                                    initialValue:formData.localTaxBudgetName,
                                })(
                                    <Input/>
                                )}
                            </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label={'企业所得税征收机关'}
                        >
                            {getFieldDecorator('businessIncomeTaxes', {
                                initialValue:formData.businessIncomeTaxes,
                            })(
                                <RadioGroup >
                                    <Radio value={"国税"}>国税</Radio>
                                    <Radio value={"地税"}>地税</Radio>
                                </RadioGroup>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayout}
                                label={'是否启用'}
                            >
                                {getFieldDecorator('enabledState', {
                                    initialValue:formData.enabledState,
                                })(
                                    <RadioGroup >
                                        <Radio value={false}>否</Radio>
                                        <Radio value={true}>是</Radio>
                                    </RadioGroup>
                                )}
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayout}
                                label={'是否上线'}
                            >
                                {getFieldDecorator('onlineState', {
                                    initialValue:formData.onlineState,
                                })(
                                    <RadioGroup >
                                        <Radio value={false}>否</Radio>
                                        <Radio value={true}>是</Radio>
                                    </RadioGroup>
                                )}
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayout}
                                label={'是否参与缴税统计'}
                            >
                                {getFieldDecorator('taxStatisticsState', {
                                    initialValue:formData.taxStatisticsState,
                                })(
                                    <RadioGroup >
                                        <Radio value={false}>否</Radio>
                                        <Radio value={true}>是</Radio>
                                    </RadioGroup>
                                )}
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayout}
                                label={'冻结'}
                            >
                                {getFieldDecorator('frozen', {
                                    initialValue:formData.frozen,
                                })(
                                    <RadioGroup >
                                        <Radio value={false}>否</Radio>
                                        <Radio value={true}>是</Radio>
                                    </RadioGroup>
                                )}
                            </FormItem>
                        </Col>

                    </Row>
                    <div className="submit_div"
                    >
                        <Button type="primary" htmlType="submit" className="submitForm" loading={this.props.btnloading}>
                            提交
                        </Button>

                    </div>
                </Form>
            </div>



        );
    }
}

export default Form.create()(BaseDataForm);