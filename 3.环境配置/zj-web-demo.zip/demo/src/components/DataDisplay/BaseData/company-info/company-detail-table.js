import React from 'react';
import { Col,Checkbox,  Select, Row, Table,Icon,Modal,Divider,Input,message} from 'antd';
import './company-info-style.css';
import  BaseDataForm from './company-detail-add-form'
import {apiConfig} from "../../../../configures/api.config";
import {getAjaxPost,getAjaxGet} from  '../../../../configures/commen.js'
import {timeFunc} from "../../../../configures/commen";
const Search = Input.Search;
const confirm = Modal.confirm;
export default class TaxReductionClassification extends React.Component {
    state = {
        columns: [
            {title: '操作', width: 120,dataIndex: 'handel', key: 'handel',align:'center',fixed: 'left',
                render: (text, record) => (
                    <span className="iconColor">
                          <a href="javascript:;" onClick={this.doDetail.bind(this,record)}><Icon type="edit" title="编辑" className="iconEdit" /></a>
                          <Divider type="vertical" />
                          <a href="javascript:;" onClick={this.doDelete.bind(this,record)}><Icon type="close" title="删除" className="iconDelete" /></a>
                    </span>
                )},
            {title: '序号', width: 50, dataIndex: 'key', key: 'key',align:'center',fixed: 'left',
                render: (text,record,index) => (
                    <span>
                        {index+1}
                    </span>
                )},
            {title: '公司代码', width: 150, dataIndex: 'companyCode', key: 'companyCode',align:'center',fixed: 'left'},
            {title: '公司名称',width: 200, dataIndex: 'companyName', key: 'companyName',align:'center',fixed: 'left'},
            {title: '简称',width: 150, dataIndex: 'companySimpleName', key: 'companySimpleName',align:'center'},
            {title: '母公司',width: 200, dataIndex: 'parentCompany', key: 'parentCompany',align:'center'},
            {title: '所属行业',width: 100, dataIndex: 'industryInvolvedName', key: 'industryInvolved',align:'center'},
            {title: '企业注册类型',width: 150, dataIndex: 'businessRegType', key: 'businessRegType',align:'center'},
            {title: '经济性质',width: 150, dataIndex: 'economicNature', key: 'economicNature',align:'center'},
            {title: '所在地址',width: 250, dataIndex: 'adress', key: 'adress',align:'center',
                render: (text,record,index) => (
                    <span>
                        {record.province}-{record.county}
                    </span>
                )},
            {title: '注册地址',width: 250, dataIndex: 'regCity', key: 'regCity',align:'center'},
            {title: '国税主管机关',width: 250, dataIndex: 'stateTaxAuthorities', key: 'stateTaxAuthorities',align:'center'},
            {title: '国税主管机关',width: 250, dataIndex: 'localTaxAuthorities', key: 'localTaxAuthorities',align:'center'},
            {title: '企业所得税征收机关',width: 250, dataIndex: 'businessIncomeTaxes', key: 'businessIncomeTaxes',align:'center'},
            {title: '统一社会信用代码',width: 250, dataIndex: 'socialCreditCode', key: 'socialCreditCode',align:'center'},
            {title: '有效起止时间',width: 250, dataIndex: 'time', key: 'time',align:'center',
                render: (text,record,index) => (
                    <span>
                        {record.startTime}~{record.endTime}
                    </span>
                )},
            {title: '法定代表人姓名',width: 250, dataIndex: 'legalPerson', key: 'legalPerson',align:'center'},
            {title: '开户银行',width: 250, dataIndex: 'bank', key: 'bank',align:'center'},
            {title: '开户账号',width: 250, dataIndex: 'bankNumber', key: 'bankNumber',align:'center'},
            {title: '联系电话',width: 250, dataIndex: 'telNumber', key: 'telNumber',align:'center'},
            {title: '备注',width: 250, dataIndex: 'remark', key: 'remark',align:'center'},
            {title: '是否启用',width: 250, dataIndex: 'enabledState', key: 'enabledState',align:'center',
                render: (text, record) => (
                    <Checkbox checked={text} disabled />
                )
            },
            {title: '税务是否上线',width: 250, dataIndex: 'onlineState', key: 'onlineState',align:'center',
                render: (text, record) => (
                    <Checkbox checked={text} disabled />
                )},
            {title: '国税财政预算级次',width: 250, dataIndex: 'nationalTaxBudget', key: 'nationalTaxBudget',align:'center'},
            {title: '国税财政预算级次名称',width: 250, dataIndex: 'nationalTaxBudgetName', key: 'nationalTaxBudgetName',align:'center'},
            {title: '地税财政预算级次',width: 250, dataIndex: 'localTaxBudget', key: 'localTaxBudget',align:'center'},
            {title: '地税财政预算级次名称\n',width: 250, dataIndex: 'localTaxBudgetName', key: 'localTaxBudgetName',align:'center'},
            {
                title: '冻结',
                width: 50,
                dataIndex: 'frozen',
                key: 'frozen',
                align:'center',
                render: (text, record) => (
                    <Checkbox checked={text} disabled />
                )},
        ],
        visibledAdd:false,
        formData:{startTime:timeFunc(6),endTime:timeFunc(0),frozen:false,id:'',
            enabledState:false,onlineState:false,taxStatisticsState:false,businessIncomeTaxes:"国税"},//form表单默认数据
        taxType:0,//税收类型
        formTitle:["代码","名称","冻结"],
        modalType:0,//0新增1编辑
        searchData:'',
        title:'公司明细',
        records:0,
    };
    /* 新增模态框显示*/
    addHandel=(e)=>{
        console.log("新增模态框")
        this.setState({
            visibledAdd:true,
            modalType:0,
            formData:{companyName:this.props.dataComanyHeader.companyName,companyCode:this.props.dataComanyHeader.companyCode,
                startTime:timeFunc(6),endTime:timeFunc(0),
                frozen:false,id:'',enabledState:false,onlineState:false,taxStatisticsState:false,
                businessIncomeTaxes:"国税"},//form表单默认数据
        })
    }
    /*查看编辑单个详情*/
    doDetail=(e)=>{
        this.setState({
            modalType:1,
            visibledAdd:true,
            formData:e
        })
    }
    /* 删除单个*/
    doDelete=(e)=>{
        let that=this;
        confirm({
            title: '是否确定删除?',
            content: '',
            okText: '是',
            okType: 'danger',
            cancelText: '否',
            onOk() {
                let data={ids:e.id};
                getAjaxPost(apiConfig.demo.company_detail_del,data,(e)=>{
                    if(e.status===200){
                        message.success("删除成功")
                        that.setState({
                            pageSize: 10,
                            pageNum:1,
                        })
                        setTimeout(() => {
                            that.props.getData();
                        },0);//通过延时处理
                    }
                    else{
                        message.error(e.message)
                    }
                })
            },
            onCancel() {
                console.log('Cancel');
            },
        });
    }
    /* 提交数据*/
    submitForm=(values)=>{
        values['industryInvolvedName']=values.industryInvolved.label;
        values['industryInvolvedCode']=values.industryInvolved.value;
        this.setState({
            btnloading:true,
        })
        console.log(`提交的数据${values}`,values)
        /*    let data=JSON.stringify(values)*/
        if(this.state.modalType===0){
            this.addSubmitForm(values)
        }
        else{
            this.editSubmitForm(values)
        }

    }
    addSubmitForm=(values)=>{
        delete values.id;
        getAjaxPost(apiConfig.demo.company_detail_add,values,(e)=>{
            this.setState({
                btnloading:false,
            })
            if(e.status===200){
                message.success("操作成功");
                this.setState({
                    visibledAdd:false
                })
                this.props.getData();
            } else{
                message.error(e.message)
            }
        })
    }
    editSubmitForm=(values)=>{
        getAjaxPost(apiConfig.demo.company_detail_edit,values,(e)=>{
            this.setState({
                btnloading:false,
            })
            if(e.status===200){
                message.success("操作成功")
                this.setState({
                    visibledAdd:false
                })
                setTimeout(() => {
                    this.props.getData();
                },0);//通过延时处理
            }
            else{
                message.error(e.message)
            }
        })
    }
    /* 关闭新增弹窗*/
    handelCancelForm=(e)=>{
        this.setState({
            visibledAdd:false
        })

    }



    render() {
        const {visibledAdd,columns,dataComanyHeader,modalType,formData,title,isLoading,}=this.state;
        const {dataSource}=this.props
        return (
            <Col span={24} className="create_select_type_company">
                <div className="comdetail-title">
                    <span>公司明细</span>
                    <a href="javascript:" className="a_btn" onClick={this.addHandel}><Icon type="plus" />&nbsp;新增公司明细</a>
                </div>
                <Table
                    bordered
                    scroll={{ x: 5380 }}
                    columns={columns}
                    dataSource={dataSource}
                    size="small"
                    loading={false}
                    pagination={false}
                />
                <Modal
                    visible={visibledAdd}
                    footer={null}
                    maskClosable={false}
                    onCancel={this.handelCancelForm}
                    title={`${modalType===0?'新增':'编辑'}${title}`}
                    width={900}
                    centered={true}
                >
                    {visibledAdd&&<BaseDataForm btnloading={this.state.btnloading} type={modalType} formData={formData}  checkDataType={this.checkDataType} callback={this.submitForm}/>}
                </Modal>
            </Col>
        );
    }
}
