/**
 * Created by hutao on 2017/4/16.
 */
import React from 'react';
import { Form, Icon, Input, Button, Radio,Select,Row,Col } from 'antd';
import {TreeCheck} from "../../../../configures/commen";
const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const Option = Select.Option;
class BaseDataForm extends React.Component {
    constructor(props) {
        super(props)
    }
    componentWillMount(){

    }
    handleSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            if(!err){
                this.props.callback(values)
            }
        });
    };
    handleChange=(e)=>{
        console.log(e)
    }

    render() {
        const { getFieldDecorator } = this.props.form;
        const {formData,formTitle,checkDataType,type} =this.props;
        const formItemLayout = {
            labelCol: {
                xs: { span: 8 },
                sm: { span: 8},
            },
            wrapperCol: {
                xs: { span: 14 },
                sm: { span: 14 },
            },
        };
        const formItemBtn = {
            labelCol: {
                xs: { span:24 },
                sm: { span: 24 },
            },
        };

        // let show=this.state
        return (
            <div >
                <Form onSubmit={this.handleSubmit}  className="div-from">
                    <FormItem
                        {...formItemLayout}
                        label={''}
                    >
                        {getFieldDecorator('id', {
                            initialValue: formData.id,
                        })(
                            <Input type="hidden"/>
                        )}
                    </FormItem>
                    <Row>
                        <Col span={12}><FormItem
                            {...formItemLayout}
                            label={'公司代码'}
                        >
                            {getFieldDecorator('companyCode', {
                                rules: [  { whitespace: true,message: `请输入公司代码`},{
                                    required: true, message: `请输入公司代码`,
                                    /* validator:checkDataType*/
                                }],
                                initialValue: formData.companyCode,

                            })(
                                <Input  disabled={type==1} placeholder={`请输入公司代码`}/>
                            )}
                        </FormItem>
                        </Col><Col span={12}><FormItem
                        {...formItemLayout}
                        label={'公司名称'}
                    >
                        {getFieldDecorator('companyName', {
                            rules: [  { whitespace: true,message: `请输入公司名称`},{
                                required: true, message: `请输入公司名称`,
                                max:50,
                                /*validator:checkDataType*/
                            }],
                            initialValue: formData.companyName,
                        })(
                            <Input  placeholder={`请输入公司名称`}/>
                        )}
                    </FormItem>
                    </Col>
                        <Col span={12}><FormItem
                            {...formItemLayout}
                            label={'层级代码'}
                        >
                            {getFieldDecorator('level', {
                                rules: [  { whitespace: true,message: `请输入层级代码`},{
                                    required: true, message: `请输入层级代码`,
                                    max:50,
                                    /*validator:checkDataType*/
                                }],
                                initialValue: formData.level,
                            })(
                                <Input  disabled={type==1} placeholder={`请输入层级代码`}/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={12}><FormItem
                            {...formItemLayout}
                            label={"公司类型"}
                        >
                            {getFieldDecorator('companyType', {
                                rules: [  {
                                    required: true, message: `请选择公司类型`,
                                    validator:TreeCheck
                                }],
                                initialValue: formData.companyType,
                            })(
                                <Select >
                                    <Option value={'集团公司'}>集团公司</Option>
                                    <Option value={'分公司'}>分公司</Option>
                                    <Option value={'子公司'}>子公司</Option>
                                </Select>
                            )}
                        </FormItem>
                        </Col><Col span={12}>
                        <FormItem
                            {...formItemLayout}
                            label={formTitle[2]}
                        >
                            {getFieldDecorator('frozen', {
                                initialValue: formData.frozen,
                            })(
                                <RadioGroup >
                                    <Radio value={false}>否</Radio>
                                    <Radio value={true}>是</Radio>
                                </RadioGroup>
                            )}
                        </FormItem>
                    </Col>

                    </Row>
                    <div className="submit_div"
                    >
                        <Button type="primary" htmlType="submit" className="submitForm" loading={this.props.btnloading}>
                            提交
                        </Button>

                    </div>
                </Form>
            </div>



        );
    }
}

export default Form.create()(BaseDataForm);