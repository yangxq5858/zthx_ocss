import React from 'react';
import { Col,Select, Row, Table,Icon,Modal,Divider,Input,Button,message} from 'antd';
import {apiConfig} from '../../../../configures/api.config';
import {getAjaxPost,getAjaxGet,getcompanyInfoData,timeFunc,} from '../../../../configures/commen.js';
import '../../../.././style/base-data-style.css';
import  WaterResourceTaxForm from './water-resource-tax-form'
const Search = Input.Search;
const confirm = Modal.confirm;
export default class WaterResourceTax extends React.Component {
    state = {
        columns: [
            {title: '操作', width: 80,dataIndex: 'handel', key: 'handel',align:'center',fixed: 'left',
                render: (text, record) => (
                    <span className="iconColor">
                      <a href="javascript:;" onClick={this.doDetail.bind(this,record)}><Icon type="edit" title="编辑" className="iconEdit" /></a>
                      <Divider type="vertical" />
                      <a href="javascript:;" onClick={this.doDelete.bind(this,record)}><Icon type="close" title="删除" className="iconDelete" /></a>
                    </span>
                )},
            {title: '序号', width: 50, dataIndex: 'key', key: 'key',align:'center',fixed: 'left',
                render: (text,record,index) => (
                    <span>
                        {(this.state.pageNum-1)*this.state.pageSize+index+1}
                    </span>
                )},
            {title: '公司代码', dataIndex: 'companyCode', key: 'companyCode',align:'center'},
            {title: '公司名称', dataIndex: 'companyName', key: 'companyName',align:'center'},
            {title: '水资源税源编号', dataIndex: 'taxSourceCode', key: 'taxSourceCode',align:'center'},
            {title: '取水许可证号', dataIndex: 'licenseNumber', key: 'licenseNumber',align:'center'},
            {title: '取水许可状态', dataIndex: 'licenseWaterState', key: 'licenseWaterState',align:'center',},
            {title: '取水许可审批机关', dataIndex: 'licenseApprovalAuthority', key: 'licenseApprovalAuthority',align:'center'},
            {title: '取水口所在地', dataIndex: 'locationIntake', key: 'locationIntake',align:'center'},
            {title: '取水地点', dataIndex: 'placeWaterIntake', key: 'placeWaterIntake',align:'center'},
            {title: '水源类型', dataIndex: 'waterSourceType', key: 'waterSourceType',align:'center'},
            {title: '适用税额等次', dataIndex: 'applicableAmountTax', key: 'applicableAmountTax',align:'center'},
            {title: '取水许可审批水量', dataIndex: 'waterPermitVolume', key: 'waterPermitVolume',align:'center'},
            {title: '年取用水计划', dataIndex: 'waterYearVolume', key: 'waterYearVolume',align:'center'},
            {title: '取水量核定机关', dataIndex: 'waterIntakeApprovedAuthority', key: 'waterIntakeApprovedAuthority',align:'center'},
            {title: '取水许可有效期限起', dataIndex: 'waterPermitDateStart', key: 'waterPermitDateStart',align:'center'},
            {title: '取水许可有效期限止', dataIndex: 'waterPermitDateEnd', key: 'waterPermitDateEnd',align:'center'},
            {title: '备注', dataIndex: 'remark', key: 'remark',align:'center'},
            {title: '创建人', dataIndex: 'creator', key: 'creator',align:'center'},
            {title: '创建时间', dataIndex: 'createdTime', key: 'createdTime',align:'center'},

        ],
        visibledAdd:false,
        visiblePro:false,
        taxType:0,//税收类型
        modalType:0,//0新增1编辑
        searchData:'',
        title:'水资源税主数据',
        formData:{},//form表单默认数据
        MethodDatas:[],//申报方式
        companyInfoDatas:[],//公司树
        TaxAuthorityDatas:[],//获取税务机关
        pageNum:1,
        pageSize:15,
        isLoading:false,
        dataSource:[],
        quickSearchProperties:'',
        visibleUpload:false,
        selectedRows:[],
    };
    componentDidMount = () => {
        //获取公司
        getcompanyInfoData(e=>{
            console.log('e',e);
            if(e.status==200){
                this.setState({
                    companyInfoDatas: e.data
                })
            }
        });
        this.getData()
    };
    getData=()=>{
        this.setState({
            isLoading:true,
        });
        let data={
            "pageInfo.page":this.state.pageNum,
            "pageInfo.rows":this.state.pageSize,
            "quickSearchValue":this.state.searchData,
        };
        getAjaxGet(apiConfig.demo.waterResourceTax_all,data,this.getDataReturn)
    };
    getDataReturn=(e)=>{
        this.setState({
            isLoading:false,
        })
        console.log('e',e);
        if(e.status===200) {
            this.setState({
                dataSource:e.data.rows,
                records: e.data.records,
            })
        }
        else{
            message.error(e.message);
        }
    };
    /* 新增模态框显示*/
    addHandel=(e)=>{
        console.log("新增模态框")
        this.setState({
            modalType:0,
            visibledAdd:true,
            formData:{
                id:'',
                companyCode:'',
                companyName:'',
                taxSourceCode:'',
                licenseNumber:'',
                licenseWaterState:'',
                licenseApprovalAuthority:'',
                locationIntake:'',
                placeWaterIntake:'',
                waterSourceType:'',
                applicableAmountTax:'',
                waterPermitVolume:'',
                waterYearVolume:'',
                waterIntakeApprovedAuthority:'',
                waterPermitDateStart:timeFunc(0),
                waterPermitDateEnd:timeFunc(0),
                remark:'',
            }});
    }
    /* 提交数据*/
    submitForm=(values)=>{
        this.setState({
            btnloading:true,
        })
        console.log(`提交的数据${values}`,values);
        let data={
            id:values.id,
            companyName:values.companyInfo.label,
            companyCode:values.companyInfo.value,
            taxSourceCode:values.taxSourceCode,
            licenseNumber:values.licenseNumber,
            licenseWaterState:values.licenseWaterState,
            licenseApprovalAuthority:values.licenseApprovalAuthority,
            locationIntake:values.locationIntake,
            placeWaterIntake:values.placeWaterIntake,
            waterSourceType:values.waterSourceType,
            applicableAmountTax:values.applicableAmountTax,
            waterPermitVolume:values.waterPermitVolume,
            waterYearVolume:values.waterYearVolume,
            waterIntakeApprovedAuthority:values.waterIntakeApprovedAuthority,
            waterPermitDateStart:values.waterPermitDate[0],
            waterPermitDateEnd:values.waterPermitDate[1],
            remark:values.remark,
        }
        if(this.state.modalType===0){
            this.addSubmitForm(data)
        }
        else{
            this.editSubmitForm(data);

        }
    };
    // 提交新增数据
    addSubmitForm=(values)=>{
        delete values.id;
        getAjaxPost(apiConfig.demo.waterResourceTax_add,values,(e)=>{
            this.setState({
                btnloading:false,
            })
            console.log('e', e);
            if(e.status===200){
                message.success("操作成功");
                this.setState({
                    visibledAdd:false,
                })
                this.getData();
            } else{
                message.error(e.message)
            }
        })
    };
    editSubmitForm=(values)=>{
        getAjaxPost(apiConfig.demo.waterResourceTax_edit,values,(e)=>{
            this.setState({
                btnloading:false,
            })
            if(e.status===200){
                message.success("操作成功");
                this.setState({
                    visibledAdd:false
                })
                this.getData();
            } else{
                message.error(e.message)
            }
        })
    }
    /* 关闭新增弹窗*/
    handelCancelForm=(e)=>{
        this.setState({
            visibledAdd:false,
            visiblePro:false
        })

    }
    /* 验证数据*/
    checkDataType=(rule, value, callback)=>{
        if (value != "测试") {
            callback("测试")
        } else {
            callback();
        }
    }

    /*查看编辑单个详情*/
    doDetail=(e)=>{
        console.log("详情",e)
        this.setState({
            modalType:1,
            visibledAdd:true,
            formData:e
        })
    }
    /* 删除单个*/
    doDelete=(e)=>{
        let that=this;
        confirm({
            title: '是否确定删除?',
            content: '',
            okText: '是',
            okType: 'danger',
            cancelText: '否',
            onOk() {
                let data={id:e.id};
                getAjaxPost(apiConfig.demo.waterResourceTax_del,data,(e)=>{
                    if(e.status===200){
                        message.success("删除成功")
                        that.setState({
                            pageSize: 15,
                            pageNum:1,
                        })
                        setTimeout(() => {
                            that.getData();
                        },0);//通过延时处理
                    }
                    else{
                        message.error(e.message)
                    }
                })
            },
            onCancel() {
                console.log('Cancel');
            },
        });
    }
    /* 搜索框*/
    searchHandel=(searchData)=>{
        this.setState({
            searchData:searchData,
            pageSize: 15,
            pageNum:1,
        })
        setTimeout(() => {
            this.getData();
        },0);//通过延时处理

    }
    changeNum=(page,num)=>{
        this.setState({
            pageNum:page,
            pageSize:num,
        })
        setTimeout(() => {
            this.getData();
        },0);//通过延时处理
    }
    /* 文件上传按钮回调*/
    handleUpload=(formData)=>{
        console.log("formData,",formData)
        this.execlcallback();

    }
    execlcallback=(data)=>{
        if(data.status===200){
            message.success("操作成功");
            this.setState({
                visibleUpload:false
            })
            setTimeout(() => {
                this.getData();
            },0);//通过延时处理
        } else{
            message.error(data.message)
        }
    };
    excelOut=()=>{
        console.log(this.state.searchData)
        window.open(apiConfig.demo.export+'?type=ReservoirFundData&&quickSearchValue='+this.state.searchData);//此处方法用于数据导出
    };
    /* 取消文件上传*/
    handelCancelUpload=(e)=>{
        this.setState({
            visibleUpload: false,
        })
    };
    render() {
        const {selectedRows,pageNum,pageSize,visibledAdd,columns,modalType,formData,title,companyInfoDatas,
            TaxAuthorityDatas,dataSource,records,visibleUpload,}=this.state;
        return (
            <div>
                <Row type="flex" align="middle" className="base-data-header">
                    <Col span={24}>
                        <span className="span">{title}</span>
                        <Search
                            className="search-input"
                            placeholder="请输入关键字查询"
                            onSearch={this.searchHandel}
                            style={{ width: 200 }}
                        />
                    </Col>
                </Row>
                <Row className="base-data-operator">
                    <Col span={24}>
                        <div className="operas_div">
                            <a href="javascript:" className="a_btn" onClick={this.addHandel}><Icon type="plus" />&nbsp;新增</a>
                            <a href="javascript:" className="a_btn" onClick={this.excelOut}><Icon type="cloud-download" />&nbsp;导出到Excel</a>

                        </div>
                    </Col>
                </Row>
                <Row type="flex">
                    <Col span={24}>
                        <div className="tablelist_header_wrapper_enterpris">
                            <div className="table_header">

                            </div>
                        </div>
                        <div className="tableList">
                            <Table
                                bordered
                                columns={columns}
                                dataSource={dataSource}
                                size="small"
                                scroll={{ x: 3000 }}
                                loading={false}
                                className={'Heightline'}
                                // rowSelection={{
                                //     onChange: this.checkRows
                                // }}
                                pagination={{//根据ant中pagination组件可以添加相应的参数,此处只简单进行处理
                                    showTotal: () => <span>共 {records} 条记录</span>,
                                    current:pageNum,
                                    pageSize:pageSize,
                                    onChange:this.changeNum,
                                    total:records,
                                }}
                            />
                        </div>

                    </Col>

                </Row>
                <Modal
                    visible={visibledAdd}
                    footer={null}
                    maskClosable={false}
                    onCancel={this.handelCancelForm}
                    title={`${modalType===0?'新增':'编辑'}${title}`}
                    width={'80%'}
                >
                    {visibledAdd&&<WaterResourceTaxForm type={modalType} companyInfoDatas={companyInfoDatas}
                                                         formData={formData} checkDataType={this.checkDataType}
                                                         btnloading={this.state.btnloading} callback={this.submitForm}/>}
                </Modal>


            </div>
        );
    }
}
