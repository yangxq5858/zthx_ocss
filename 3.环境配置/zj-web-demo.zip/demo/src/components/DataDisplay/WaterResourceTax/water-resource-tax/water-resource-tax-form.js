/**
 * Created by miaomiao on 2017/9/18.
 * 销项开票数据
 */
import React from 'react';
import { Form, Icon, Input, Button, Radio,Select,Row,Col,TreeSelect ,DatePicker } from 'antd';
import moment from 'moment';
import {getTaxRate, getAjaxGet, getbusinessRange, TreeCheck,} from '../../../../configures/commen'
/*import  TreeSelect from '../../DataEntry/tax-type-select/tax-type-select'*/
const FormItem = Form.Item;
const Option = Select.Option;
const RadioGroup = Radio.Group;
const {  RangePicker,MonthPicker } = DatePicker;
const TreeNode = TreeSelect.TreeNode;
const dateFormat1 = 'YYYY-MM';

class WaterResourceTaxForm extends React.Component {
    constructor(props) {
        super(props)
    }
    state = {
        mode: ['month', 'month'],
    }
    componentDidMount(){
        if(this.props.type===1){
            getbusinessRange( this.props.formData.companyCode,e=>{
                if(e.status===200){
                    this.setState({
                        bussniessData:e.data.rows,
                    })
                }
            })
        }
    }
    handlePanelChange = (value, mode) => {
        console.log(value[0].format('YYYY-MM'),value[1].format('YYYY-MM'),mode);
        this.props.form.setFieldsValue({
            waterPermitDate:[moment(value[0].format('YYYY-MM'), dateFormat1),moment(value[1].format('YYYY-MM'), dateFormat1)]
        })
        this.setState({
            mode: [
                mode[0] === 'date' ? 'month' : mode[0],
                mode[1] === 'date' ? 'month' : mode[1],
            ],
        });
    }
    handleSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFields((err, fieldsValue) => {
            console.log("valu",fieldsValue);
            if(!err){
                const rangeValue = fieldsValue['waterPermitDate'];
                const values = {
                    ...fieldsValue,
                    'waterPermitDate': [rangeValue[0].format('YYYY-MM'), rangeValue[1].format('YYYY-MM')],
                };
                this.props.callback(values)
            }

        });
    };
    handleChange=(e)=>{
        console.log(e)
    };
    callbackTree=(e)=>{};

    IsNumber=(rule, value, callback)=>{
        if(value!=''){
            let reg = /^\d+(\.\d+)?$/;
            if(reg.test(value)){
                callback()
            }
            else{
                callback("请输入正确的数字")
            }
            return
        }
        else{
            callback()
        }
    }

    render() {
        const { getFieldDecorator } = this.props.form;
        const {formData,companyInfoDatas,} =this.props;
        const {mode,} = this.state

        const formItemLayout = {
            labelCol: {
                xs: { span: 8 },
                sm: { span: 8},
            },
            wrapperCol: {
                xs: { span: 14 },
                sm: { span: 14 },
            },
        };
        const loop=data=>data.map(function(item){
            if (item.childrenList && item.childrenList.length) {
                return <TreeNode disabled={item.frozen} icon={<Icon type="folder" />} key={item.code} value={item.code} title={item.name}>{loop(item.childrenList)}</TreeNode>;
            }
            else{
                return <TreeNode disabled={item.frozen} icon={<Icon type="file-text" />}  value={item.code} title={item.name} key={item.code}/>
            }

        })
        const loopCom=data=>data.map(function(item){
            if (item.childrenList && item.childrenList.length) {
                return <TreeNode disabled={item.frozen} icon={<Icon type="folder" />} key={item.companyCode} value={item.companyCode} title={item.companyName}>{loopCom(item.childrenList)}</TreeNode>;
            }
            else{

                return <TreeNode disabled={item.frozen} icon={<Icon type="file-text" />} key={item.companyCode} value={item.companyCode} title={item.companyName}/>
            }

        });
        // let show=this.state
        return (
            <div >
                <Form onSubmit={this.handleSubmit}  className="div-from wid Heightline">
                    <FormItem
                        {...formItemLayout}
                        label=""
                    >
                        {getFieldDecorator('id', {
                            initialValue: formData.id,
                        })(
                            <Input type="hidden"/>
                        )}
                    </FormItem>
                    <Row>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label="公司"
                        >
                            {getFieldDecorator('companyInfo', {
                                rules: [ {
                                    required: true, message: '请选择公司',
                                    validator:TreeCheck,
                                }],
                                initialValue:{value: formData.companyCode, label: formData.companyName}
                            })(

                                <TreeSelect
                                    labelInValue

                                    dropdownStyle={{ maxHeight: 300, overflow: 'auto' }}
                                    placeholder="请选择"
                                    allowClear={false}
                                    treeDefaultExpandAll
                                >
                                    {companyInfoDatas!==null?loopCom(companyInfoDatas):
                                        <TreeNode  disabled={true} icon={<Icon type="file-text" />}  value={0} title={'Not Found'} key={1}/>
                                    }
                                </TreeSelect>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label="水资源税源编号"
                        >
                            {getFieldDecorator('taxSourceCode', {
                                rules: [ { whitespace: true,message: `请输入水资源编号`},
                                    {
                                    required: true, message: '请输入水资源编号',
                                }],
                                initialValue:formData.taxSourceCode,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayout}
                                label={'取水许可状态'}
                            >
                                {getFieldDecorator('licenseWaterState', {
                                    rules: [ {
                                        required: true, message: '请选择取水许可状态',
                                    }],
                                    initialValue:formData.licenseWaterState,
                                })(
                                    <RadioGroup >
                                        <Radio value={'未办理'}>未办理</Radio>
                                        <Radio value={'已办理'}>已办理</Radio>
                                    </RadioGroup>
                                )}
                            </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label="取水许可证号"
                        >
                            {getFieldDecorator('licenseNumber', {
                                rules: [ { whitespace: true,message: `请输入取水许可证号`},{
                                    required: true, message: '请输入取水许可证号',
                                }],
                                initialValue:formData.licenseNumber,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label="取水许可审批机关"
                        >
                            {getFieldDecorator('licenseApprovalAuthority', {
                                rules: [ { whitespace: true,message: `请输入取水许可审批机关`},{
                                    required: true, message: '请输入取水许可审批机关',
                                }],
                                initialValue:formData.licenseApprovalAuthority,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label="取水口所在地"
                        >
                            {getFieldDecorator('locationIntake', {
                                rules: [  { whitespace: true,message: `请输入取水口所在地`},{
                                    required: true, message: '请输入取水口所在地',
                                }],
                                initialValue:formData.locationIntake,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label="取水地点"
                        >
                            {getFieldDecorator('placeWaterIntake', {
                                rules: [  { whitespace: true,message: `请输入取水地点`},{
                                    required: true, message: '请输入取水地点',
                                }],
                                initialValue:formData.placeWaterIntake,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label="水源类型"
                        >
                            {getFieldDecorator('waterSourceType', {
                                initialValue:formData.waterSourceType,
                                rules: [ {
                                    required: true,
                                    message: `请选择水源类型`,
                                    validator:TreeCheck,
                                }],
                            })(
                                <Select>
                                    <Option value={'地表水'}>地表水</Option>
                                    <Option value={'地下水'}>地下水</Option>
                                    <Option value={'自来水'}>自来水</Option>
                                </Select>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label="适用税额等次"
                        >
                            {getFieldDecorator('applicableAmountTax', {
                                rules: [  { whitespace: true,message: `请输入适用税额等次`},{
                                    required: true, message: '请输入适用税额等次',
                                }],
                                initialValue:formData.applicableAmountTax,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label="取水许可审批水量"
                        >
                            {getFieldDecorator('waterPermitVolume', {
                                initialValue:formData.waterPermitVolume,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label="年取用水计划"
                        >
                            {getFieldDecorator('waterYearVolume', {
                                initialValue:formData.waterYearVolume,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label="取水量核定机关"
                        >
                            {getFieldDecorator('waterIntakeApprovedAuthority', {
                                rules: [  { whitespace: true,message: `请输入取水量核定机关`},{
                                    required: true, message: '请输入取水量核定机关',
                                }],
                                initialValue:formData.waterIntakeApprovedAuthority,
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label="取水许可有效期限"
                        >
                            {getFieldDecorator('waterPermitDate', {
                                rules: [ {
                                    required:true,
                                    message: '请选择取水许可有效期限起止',
                                }],
                                initialValue:[moment(formData.waterPermitDateStart, dateFormat1),moment(formData.waterPermitDateEnd, dateFormat1)]
                            })(
                                <RangePicker allowClear={false}  placeholder={['取水许可有效期限起', '取水许可有效期限止']}
                                             format="YYYY-MM"
                                             mode={mode}
                                             onPanelChange={this.handlePanelChange}
                                />
                            )}
                        </FormItem>
                        </Col>
                        <Col span={8}><FormItem
                            {...formItemLayout}
                            label="备注"
                        >
                            {getFieldDecorator('remark', {
                                initialValue:formData.remark
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        </Col>
                    </Row>
                    <div className="submit_div"
                    >
                        <Button type="primary" htmlType="submit" className="submitForm" loading={this.props.btnloading}>
                            提交
                        </Button>

                    </div>
                </Form>
            </div>



        );
    }
}

export default Form.create()(WaterResourceTaxForm);