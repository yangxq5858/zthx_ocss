import {connect} from 'react-redux';
import Modal from './modal-wrapper-view';
import {
    companyInfoCloseChildrenmodalActions,
    companyInfoClosemodalActions,
    closeModalActions,
    closeChildrenModalActions
} from './modal-wrapper-action';

/**
 * 存储对象(store)在处理逻辑动作(action)后，产生新数据状态机(state)返回给用户
 */
const mapStateToProps = (state) => {
    return {
        modalWrapperTodos: state.modalWrapperTodos
    };
};

/**
 * 用户操作的逻辑动作(action)发送给存储对象(store)，处理对应业务逻辑的执行(reducer)，产生新的数据状态机(state)
 */
const mapDispatchToProps = (dispatch) => {
    return {
        onClose: (e) => dispatch(closeModalActions(e)),
        childrenOnClose: (e) => dispatch(closeChildrenModalActions(e)),
        companyInfoOnClose: (e) => dispatch(companyInfoClosemodalActions(e)),
        companyInfoOhildrenOnClose: (e) => dispatch(companyInfoCloseChildrenmodalActions(e))
    };
};

/**
 * 连接对应UI组件进行渲染
 */
export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Modal);
