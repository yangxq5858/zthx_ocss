import {companyInfoModalWrapperOperas, modalWrapperOperas} from './modal-wrapper-action';

/**
 * 数据状态机初始值
 */
const initialState = {
    modalVisible: false
};

/**
 * 根据得到的action结果赋值并产生新的state
 */
export const modalWrapperTodos = (state = initialState, action) => {
    switch (action.type) {
        case modalWrapperOperas.success:
            return Object.assign({}, state, action.payload);
        case companyInfoModalWrapperOperas.success:
            return Object.assign({}, state, action.payload);
        default:
            return state;
    }
};
