import {createAction, createTypes} from '../../../others/actions';

/**
 * action types
 */
export const modalWrapperOperas = createTypes('companyInfo');
export const companyInfoModalWrapperOperas = createTypes('companyInfo');

/**
 * action store
 */
export const closeModalActions = (param = undefined) => {
    return createAction('关闭抽屉', modalWrapperOperas.success, {modalVisible: false});
};
export const closeChildrenModalActions = (param = undefined) => {
    return createAction('关闭子抽屉', modalWrapperOperas.success, {childrenModalVisible: false});
};
export const companyInfoClosemodalActions = (param = undefined) => {
    return createAction('关闭抽屉', companyInfoModalWrapperOperas.success, {companyInfoModalVisible: false});
};
export const companyInfoCloseChildrenmodalActions = (param = undefined) => {
    return createAction('关闭子抽屉', companyInfoModalWrapperOperas.success, {companyInfoChildrenmodalVisible: false});
};

