/**
 * @Title: modal.view
 * @ProjectName pool-web
 * @Description: TODO
 * @author fuxiang_dai
 * @date 2018/8/6 22:13
 */

import React from 'react';
import {Modal, Spin} from 'antd';

import ManuallyPaymentConfirm from '../manually-payment-confirm/manually-payment-confirm-container';
import AdjustApply from '../../DataEntry/adjust-apply/adjust-apply-container';
import ExecutorSelected from '../../DataEntry/executor-selected/executor-selected-container';
import QueryAdvanced from '../../DataEntry/query-advanced/query-advanced-container';

import {WrappedCompanyInfoAddForm} from '../company-info-add/company-info-add-view';
import {WrappedCompanyInfoEditForm} from '../company-info-edit/company-info-edit-view';
import './modal-wrapper-style.css';

export default class modalContainer extends React.Component {
    /*初始化属性值*/
    static defaultProps = {
        width: 339
    };
    /*根据前端传入的类型，展示不同的组件内容*/
    whichContentShow = (type) => {
        switch (type) {
            case 'company-info副本-add':
                return <WrappedCompanyInfoAddForm datarecord={this.props.datarecord}/>;
            case 'company-info副本-edit':
                return <WrappedCompanyInfoEditForm datarecord={this.props.datarecord}/>;
            default:
                return;
        }
    };

    render() {
        const {
            modalType,
            childrenModalType,
            width, modalVisible,
            onClose,
            title,
            childrenModalVisible,
            modalLoading,
            childrenModalTitle,
            cancelText,
            okText,
            height,
            datarecord
        } = this.props;
        const childrenOnClose = this.props.childrenOnClose;
        const content = this.whichContentShow(modalType);
        return (
            <div>
                <Modal
                    cancelText={cancelText}
                    okText={okText}
                    title={title}
                    width={width}
                    height={height}
                    placement="right"
                    onCancel={onClose}
                    maskClosable={true}
                    visible={modalVisible}
                    style={{
                        height: 'calc(100% - 55px)',
                        overflow: 'auto',
                        paddingBottom: 53
                    }}
                >
                    <Spin spinning={false} className="modal_wrapper_spin">
                        {content}
                    </Spin>
{/*
                    <Modal
                        title={childrenModalTitle}
                        width={320}
                        onCancel={childrenOnClose}
                        maskClosable={true}
                        visible={childrenModalVisible}
                    >
                        {this.whichContentShow(childrenModalType)}
                    </Modal>
*/}
                </Modal>
            </div>
        );
    }
}
