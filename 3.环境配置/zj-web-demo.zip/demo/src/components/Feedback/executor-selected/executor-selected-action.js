/**
 * @Title: payment-confirm-action
 * @ProjectName pool-web
 * @Description: 执行人选择-action
 * @author fuxiang_dai
 * @date 2018/8/7  10:55
 */

import agent from 'superagent';

import {createAction, createOperas, createTypes} from '../../../others/actions';
import {apiConfig} from '../../../configures/api.config';
import {isEmpty} from '../../../others/tool';

/**
 * action types
 */
export const executorSelectedTypes = createTypes('executorSelected');
export const executorSelectedOperas = createOperas('executorSelected');

/**
 * action store
 */
export const executorSelectedActions = (param = undefined, async = true) => {
    if (async) {
        // 异步：返回函数，函数中dispatch不同的action对象到store中
        return (dispatch) => {
            dispatch(createAction('加载中...', executorSelectedTypes.loading));

            // agent.post(apiConfig.demo.findAll).send({}) // post方式
            agent.get(apiConfig.demo.findAll).query({}) // get方式
                .end((err, res) => { // end函数体
                    /* err为空：请求成功；不为空：请求错误(这时res.body也为空)；也可通过直接判断res.ok===true或res.status===200进行处理；*/
                    if (isEmpty(err)) {
                        if (res.ok) {
                            dispatch(createAction('请求成功', executorSelectedTypes.success, res.body));
                        } else {
                            dispatch(createAction('请求失败', executorSelectedTypes.error, res.error, true));
                        }
                    } else {
                        dispatch(createAction('请求错误', executorSelectedTypes.error, err, true));
                    }
                });
        };
    } else {
        // 同步：返回action对象到store中
        return createAction('请求演示', executorSelectedTypes.success, {
            code: 'demo',
            text: 'Demo请求接口'
        });
    }
};
