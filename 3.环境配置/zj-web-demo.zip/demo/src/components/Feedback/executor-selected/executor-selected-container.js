/**
 * @Title: payment-confirm-container
 * @ProjectName pool-web
 * @Description: 执行人选择-容器组件
 * @author fuxiang_dai
 * @date 2018/8/7  10:50
 */
import {connect} from 'react-redux';

import ExecutorSelected from './executor-selected-view';

const mapStateToProps = (state) => {
    return {
        executorSelectedTodos: state.executorSelectedTodos
    };
};
export default connect(mapStateToProps)(ExecutorSelected);
