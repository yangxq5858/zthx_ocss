/**
 * @Title: ayment-adjustment-view
 * @ProjectName pool-web
 * @Description: 执行人选择-视图组件
 * @author fuxiang_dai
 * @date 2018/8/7  10:30
 */
import React from 'react';
import {Affix, Button, Radio} from 'antd';

import './executor-selected-view.css';
import {browserHistory} from 'react-router';

const RadioGroup = Radio.Group;
export default class ExecutorSelected extends React.Component {
    state = {
        /*visible: true,*/
        bottom: 10,
        value: '张良'
    };

    onChange = (e) => {
        console.log('radio checked', e.target.value);
        this.setState({
            value: e.target.value
        });
    };

    onClose = () => {
        this.setState({
            visible: false
        });
    };
    /*点击发起流程进入选择执行人页面*/
    topaymentConfirm = (event) => {
        event.preventDefault();
        /*const userName = event.target.elements[0].value;
        const repo = event.target.elements[1].value;*/
        const path = `drawer_container`;
        browserHistory.push(path);
    };

    render() {
        const radioStyle = {
            display: 'block',
            height: '30px',
            lineHeight: '30px'
        };
        const {executorSelected} = this.props.executorSelectedTodos;
        return (
            <div>
                {/*<Drawer
                    width={320}
                    title="选择执行人"
                    placement="right"
                    closable={true}
                    onClose={this.onClose}
                    visible={this.state.visible}
                >*/}
                <RadioGroup onChange={this.onChange} value={this.state.value}>
                    {
                        executorSelected.map((value, i) => {
                            return <Radio key={i} style={radioStyle} value={value}>{value}</Radio>;
                        })
                    }
                </RadioGroup>
                <Affix style={{position: 'absolute', bottom: 23, right: 24}}>
                    <Button type="primary" onClick={this.onClose}>
                        确定
                    </Button>
                </Affix>
                <Affix style={{position: 'absolute', bottom: 23, right: 100}}>
                    <Button onClick={this.topaymentConfirm}>
                        上一步
                    </Button>
                </Affix>
                {/*</Drawer>*/}
            </div>
        );
    }
}
