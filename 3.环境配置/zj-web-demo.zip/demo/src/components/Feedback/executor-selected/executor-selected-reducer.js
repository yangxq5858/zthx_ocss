/**
 * @Title: payment-confirm-reducer
 * @ProjectName pool-web
 * @Description: 执行人选择-reducer
 * @author fuxiang_dai
 * @date 2018/8/7  10:54
 */

import {executorSelectedOperas, executorSelectedTypes} from './executor-selected-action';

/**
 * 数据状态机初始值
 */
const initialState = {
    executorSelected: ['张良', '刘宇西', '李莉', '王骥']
};


/**
 * 根据得到的action结果赋值并产生新的state
 */
export const executorSelectedTodos = (state = initialState, action) => {
    switch (action.type) {
        case executorSelectedTypes.loading:
        case executorSelectedTypes.success:
        case executorSelectedTypes.error:
        case executorSelectedOperas.add.loading:
        case executorSelectedOperas.add.success:
        case executorSelectedOperas.add.error:
            return Object.assign({}, state, {
                executorSelected: action.executorSelected
            });
        default:
            return state;
    }
};
