/**
 * @Title: payment-details-reducer
 * @ProjectName pool-web
 * @Description: 支付明细展示-reducer
 * @author fuxiang_dai
 * @date 2018/8/7  9:19
 */

import {paymentDetailsTypes, paymentDetailsOperas} from './company-info-edit-action';

/**
 * 数据状态机初始值
 */
const initialState = {
    paymentDetails: {
        cheque_name: '张三良',
        cheque_blank_code: '中央银行',
        cheque_blank_name: '中国工商银行合肥长江东路支行',
        cheque_blank_account: '5487911355844',
        voucher_no: '56745421587985',
        voucher_summary: '宣传物料购买',
        operator: '杨丽',
        amount: 925000.00,
        channel_name: '银企直联',
        pay_blank_code: '财务公司',
        strategy_name: '定日',
        account_period: '30',
        due_date: '2018-8-30',
        transresult_name: '正常',
        state_name: '未确认'
    }
};

/**
 * 根据得到的action结果赋值并产生新的state
 */
export const paymentDetailsTodos = (state = initialState, action) => {
    switch (action.type) {
        case paymentDetailsTypes.loading:
        case paymentDetailsTypes.success:
        case paymentDetailsTypes.error:
        case paymentDetailsOperas.add.loading:
        case paymentDetailsOperas.add.success:
        case paymentDetailsOperas.add.error:
            return Object.assign({}, state, {
                paymentDetails: action.paymentDetails
            });
        default:
            return state;
    }
};
