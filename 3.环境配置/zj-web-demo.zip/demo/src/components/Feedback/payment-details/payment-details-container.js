/**
 * @Title: payment-details-container
 * @ProjectName pool-web
 * @Description: 支付明细展示-容器组件
 * @author fuxiang_dai
 * @date 2018/8/7  8:59
 */
import {connect} from 'react-redux';

import PaymentDetails from './payment-details-view';

const mapStateToProps = (state) => {
    return {
        paymentDetailsTodos: state.paymentDetailsTodos
    };
};
export default connect(mapStateToProps)(PaymentDetails);
