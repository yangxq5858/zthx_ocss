/**
 * @Title: payment-details-view
 * @ProjectName pool-web
 * @Description: 支付明细展示-视图组件
 * @author fuxiang_dai
 * @date 2018/8/6  8:59
 */
import React from 'react';
import {/*Drawer, Button, */Row, Col, Divider} from 'antd';

import './payment-details-view.css';

export default class PaymentDetails extends React.Component {
    /*state = {visible: false};

    showDrawer = () => {
        this.setState({
            visible: true,
        });
    };

    onClose = () => {
        this.setState({
            visible: false,
        });
    };*/

    render() {
        return (
            <div>
                {/*<Button type="primary" onClick={this.showDrawer}>
                    Open
                </Button>
                <Drawer
                    width={500}
                    title="查看明细"
                    placement="right"
                    closable={true}
                    onClose={this.onClose}
                    visible={this.state.visible}
                >*/}
                    <div className="payment-details-div">
                        <Row className="payment-details-row">
                            <Col className="payment-details" span={12}>收款方名称：</Col>
                            <Col span={12}>{this.props.paymentDetailsTodos.paymentDetails.cheque_name}</Col>
                        </Row>
                        <Row className="payment-details-row">
                            <Col className="payment-details" span={12}>收款银行类别：</Col>
                            <Col span={12}>{this.props.paymentDetailsTodos.paymentDetails.cheque_blank_code}</Col>
                        </Row>
                        <Row className="payment-details-row">
                            <Col className="payment-details" span={12}>收款银行名称：</Col>
                            <Col span={12} className="payment-details-value">{this.props.paymentDetailsTodos.paymentDetails.cheque_blank_name}</Col>
                        </Row>
                        <Row className="payment-details-row">
                            <Col className="payment-details" span={12}>收款方银行账号：</Col>
                            <Col span={12}>{this.props.paymentDetailsTodos.paymentDetails.cheque_blank_account}</Col>
                        </Row>
                    </div>
                    <Divider className="payment-details-divider"/>
                    <div className="payment-details-div">
                        <Row className="payment-details-row">
                            <Col className="payment-details" span={12}>挂账记账凭证：</Col>
                            <Col span={12}>{this.props.paymentDetailsTodos.paymentDetails.voucher_no}</Col>
                        </Row>
                        <Row className="payment-details-row">
                            <Col className="payment-details" span={5}>凭证摘要：</Col>
                            <Col span={6}>{this.props.paymentDetailsTodos.paymentDetails.voucher_summary}</Col>
                            <Col className="payment-details" span={6}>业务经办人：</Col>
                            <Col span={4}>{this.props.paymentDetailsTodos.paymentDetails.operator}</Col>
                        </Row>
                    </div>
                    <Divider className="payment-details-divider"/>
                    <div className="payment-details-div">
                        <Row className="payment-details-row">
                            <Col className="payment-details" span={5}>支付金额：</Col>
                            <Col span={6}>{this.props.paymentDetailsTodos.paymentDetails.amount}</Col>
                            <Col className="payment-details" span={5}>支付渠道：</Col>
                            <Col span={4}>{this.props.paymentDetailsTodos.paymentDetails.channel_name}</Col>
                        </Row>
                        <Row className="payment-details-row">
                            <Col className="payment-details" span={5}>支付银行：</Col>
                            <Col span={6}>{this.props.paymentDetailsTodos.paymentDetails.pay_blank_code}</Col>
                            <Col className="payment-details" span={5}>支付策略：</Col>
                            <Col span={4}>{this.props.paymentDetailsTodos.paymentDetails.strategy_name}</Col>
                        </Row>
                        <Row className="payment-details-row">
                            <Col className="payment-details" span={4}>账期：</Col>
                            <Col span={6}>{this.props.paymentDetailsTodos.paymentDetails.account_period}</Col>
                            <Col className="payment-details" span={4}>到期日：</Col>
                            <Col span={5}>{this.props.paymentDetailsTodos.paymentDetails.due_date}</Col>
                        </Row>
                    </div>
                    <Divider className="payment-details-divider"/>
                    <div className="payment-details-div">
                        <Row className="payment-details-row">
                            <Col className="payment-details" span={5}>单据状态：</Col>
                            <Col span={6}>{this.props.paymentDetailsTodos.paymentDetails.transresult_name}</Col>
                            <Col className="payment-details" span={5}>支付状态：</Col>
                            <Col span={4}>{this.props.paymentDetailsTodos.paymentDetails.state_name}</Col>
                        </Row>
                    </div>
                {/*</Drawer>*/}
            </div>
        );
    }
}
