/**
 * @Title: ayment-adjustment-view
 * @ProjectName pool-web
 * @Description: 高级查询-视图组件
 * @author fuxiang_dai
 * @date 2018/8/7  10:30
 */
import React from 'react';
import {Col, Form, Input, Row, Select} from 'antd';

import './company-info-add-view.css';

const FormItem = Form.Item;
const Option = Select.Option;

// const param='param';
class CompanyInfoAdd extends React.Component {
    state = {
        visible: true,
        bottom: 10,
        expand: false,
        spread: '展开',
        display: 'none'
    };

    handleSearch = (e) => {
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            console.log('Received values of form: ', values);
        });
    };

    handleReset = () => {
        this.props.form.resetFields();
    };

    toggle = () => {
        const {expand, display} = this.state;
        if (display === 'none') {
            this.setState({
                display: 'block',
                spread: '收起'
            });
        } else {
            this.setState({
                display: 'none',
                spread: '展开'
            });
        }
        this.setState({
            expand: !expand
        });
    };

    // To generate mock Form.Item
    getFields() {
        const count = this.state.expand ? 10 : 6;
        const {getFieldDecorator} = this.props.form;
        const formItemLayout = {
            labelCol: {span: 8},
            wrapperCol: {span: 16}
        };
        const {searchItems, display} = this.state;
        return (
            <div>
                <Row type="flex">
                    <Col span={10}>
                        <FormItem
                            {...formItemLayout}
                            label={`父级：`}
                        >四川长虹电子集团有限公司
                        </FormItem>

                    </Col>
                </Row>
                <Row type="flex">
                    <Col span={10}>
                        <FormItem
                            {...formItemLayout}
                            label={`公司代码：`}
                        ><Input placeholder="公司代码"/>
                        </FormItem>

                    </Col>
                    <Col offset={1} span={12}>
                        <FormItem
                            {...formItemLayout}
                            label={`公司名称：`}
                        ><Input placeholder="公司名称"/>
                        </FormItem>

                    </Col>
                </Row>
                <Row type="flex">
                    <Col span={10}>
                        <FormItem
                            {...formItemLayout}
                            label={`层级代码：`}
                        ><Input placeholder="层级代码"/>
                        </FormItem>

                    </Col>
                    <Col offset={1} span={12}>
                        <FormItem
                            {...formItemLayout}
                            label={`公司类型：`}
                            hasFeedback
                        ><Select placeholder="集团公司">
                            <Option value="集团公司">集团公司</Option>
                            <Option value="分公司">分公司</Option>
                            <Option value="子公司">子公司</Option>
                        </Select>
                        </FormItem>

                    </Col>
                </Row>
            </div>
        );
    }

    onClose = () => {
        this.setState({
            visible: false
        });
    };
    test5 = (param = undefined) => {
        alert('测试成功！');
        if (param !== undefined) {
            console.log('传入参数：', param);
        }
    };

    test9(param = undefined) {
        alert('测试成功！');
        if (param !== undefined) {
            console.log('传入参数：', param);
        }
    }


    test8 = (param = undefined) => {
        alert('测试成功！');
        if (param !== undefined) {
            console.log('传入参数：', param);
        }
    };

    render() {
        const {spread} = this.state;
        return (
            <div>
                <Form
                    onSubmit={this.handleSearch}
                >
                    <Row>{this.getFields()}</Row>
                </Form>
                {/* </Drawer>*/}
            </div>
        );
    }
}

export const WrappedCompanyInfoAddForm = Form.create()(CompanyInfoAdd);
let test1 = (param = undefined) => {
    alert('测试成功！');
    if (param !== undefined) {
        console.log('传入参数：', param);
    }
};

function test2(param = undefined) {
    alert('测试成功！');
    if (param !== undefined) {
        console.log('传入参数：', param);
    }
}

export const test4 = (param = undefined) => {
    alert('测试成功！');
    if (param !== undefined) {
        console.log('传入参数：', param);
    }
};
