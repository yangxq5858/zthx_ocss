/**
 * @Title: payment-details-action
 * @ProjectName pool-web
 * @Description: 支付明细展示-action
 * @author fuxiang_dai
 * @date 2018/8/7  9:07
 */
import {createAction, createOperas, createTypes} from '../../../others/actions';
import {apiConfig} from '../../../configures/api.config';
import {isEmpty} from '../../../others/tool';
import agent from 'superagent';

/**
 * action types
 */
export const paymentDetailsTypes = createTypes('paymentDetails');
export const paymentDetailsOperas = createOperas('paymentDetails');

/**
 * action store
 */
export const payDetailsActions = (param = undefined, async = true) => {
    if (async) {
        // 异步：返回函数，函数中dispatch不同的action对象到store中
        return (dispatch) => {
            dispatch(createAction('加载中...', paymentDetailsTypes.loading));

            // agent.post(apiConfig.demo.findAll).send({}) // post方式
            agent.get(apiConfig.demo.findAll).query({}) // get方式
                .end((err, res) => { // end函数体
                    /* err为空：请求成功；不为空：请求错误(这时res.body也为空)；也可通过直接判断res.ok===true或res.status===200进行处理；*/
                    if (isEmpty(err)) {
                        if (res.ok) {
                            dispatch(createAction('请求成功', paymentDetailsTypes.success, res.body));
                        } else {
                            dispatch(createAction('请求失败', paymentDetailsTypes.error, res.error, true));
                        }
                    } else {
                        dispatch(createAction('请求错误', paymentDetailsTypes.error, err, true));
                    }
                });
        };
    } else {
        // 同步：返回action对象到store中
        return createAction('请求演示', paymentDetailsTypes.success, {
            code: 'demo',
            text: 'Demo请求接口'
        });
    }
};
