/**
 * @Title: radio
 * @ProjectName pool-web
 * @Description: TODO
 * @author fuxiang_dai
 * @date 2018/8/7  14:04
 */

import React from 'react';
import {Radio} from 'antd';

const RadioGroup = Radio.Group;

export default class MyRadio extends React.Component {
    state = {
        value: 1
    };

    onChange = (e) => {
        console.log('radio checked', e.target.value);
        this.setState({
            value: e.target.value
        });
    };

    render() {
        const radioStyle = {
            display: 'block',
            height: '30px',
            lineHeight: '30px'
        };
        const {executorSelected} = this.props.executorSelectedTodos;

        return (
            <RadioGroup onChange={this.onChange} value={this.state.value}>
                <Radio style={radioStyle} value="张良">{executorSelected[0]}</Radio>
                <Radio style={radioStyle} value="刘宇西">{executorSelected[1]}</Radio>
                <Radio style={radioStyle} value="李莉">{executorSelected[2]}</Radio>
                <Radio style={radioStyle} value="王骥">{executorSelected[3]}</Radio>
            </RadioGroup>
        );
    }
}
