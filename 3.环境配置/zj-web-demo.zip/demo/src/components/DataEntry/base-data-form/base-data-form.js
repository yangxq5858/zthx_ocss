/**
 * Created by hutao on 2017/4/16.
 */
import React from 'react';
import { Form, Icon, Input, Button, Radio,Select,Row,Col } from 'antd';
import  './get-form-style.css'
const FormItem = Form.Item;
const RadioGroup = Radio.Group;
class BaseDataForm extends React.Component {
    constructor(props) {
        super(props)
    }
    componentWillMount(){

    }
    handleSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            if(!err){
                this.props.callback(values)
            }
        });
    };
    handleChange=(e)=>{
        console.log(e)
    }

    render() {
        const { getFieldDecorator } = this.props.form;
        const {formData,formTitle,checkDataType,type} =this.props;
        const formItemLayout = {
            labelCol: {
                xs: { span: 8 },
                sm: { span: 8},
            },
            wrapperCol: {
                xs: { span: 14 },
                sm: { span: 14 },
            },
        };
        const formItemBtn = {
            labelCol: {
                xs: { span:24 },
                sm: { span: 24 },
            },
        };

        // let show=this.state
        return (
            <div >
                <Form onSubmit={this.handleSubmit}  className="div-from">
                    <FormItem
                        {...formItemLayout}
                        label={''}
                    >
                        {getFieldDecorator('id', {
                            initialValue: formData.id,
                        })(
                            <Input type="hidden"/>
                        )}
                    </FormItem>
                    <Row>
                        <Col span={12}><FormItem
                        {...formItemLayout}
                        label={formTitle[0]}
                    >
                        {getFieldDecorator('code', {
                            rules: [  { whitespace: true,message: `请输入${formTitle[0]}`},{
                                required: true, message: `请输入${formTitle[0]}`,
                               /* validator:checkDataType*/
                            }],
                            initialValue: formData.code,

                        })(
                            <Input  disabled={type==1} placeholder={`请输入${formTitle[0]}`}/>
                        )}
                    </FormItem>
                    </Col>
                        <Col span={12}><FormItem
                            {...formItemLayout}
                            label={formTitle[1]}
                        >
                            {getFieldDecorator('name', {
                                rules: [  { whitespace: true,message: `请输入${formTitle[1]}`},{
                                    required: true, message: `请输入${formTitle[1]}`,
                                    max:50,
                                    /*validator:checkDataType*/
                                }],
                                initialValue: formData.name,

                            })(
                                <Input  placeholder={`请输入${formTitle[1]}`}/>
                            )}
                        </FormItem>
                        </Col>
                        <Col span={12}>
                            <FormItem
                                {...formItemLayout}
                                label={formTitle[2]}
                            >
                                {getFieldDecorator('isDefault', {
                                    initialValue: formData.isDefault,
                                })(
                                    <RadioGroup >
                                        <Radio value={false}>否</Radio>
                                        <Radio value={true}>是</Radio>
                                    </RadioGroup>
                                )}
                            </FormItem>
                        </Col>
                        <Col span={12}>
                    <FormItem
                        {...formItemLayout}
                        label={formTitle[3]}
                    >
                        {getFieldDecorator('frozen', {
                            initialValue: formData.frozen,
                        })(
                            <RadioGroup >
                                <Radio value={false}>否</Radio>
                                <Radio value={true}>是</Radio>
                            </RadioGroup>
                        )}
                    </FormItem>
                    </Col>

                    </Row>
                    <div className="submit_div"
                    >
                        <Button type="primary" htmlType="submit" className="submitForm" loading={this.props.btnloading}>
                            提交
                        </Button>

                    </div>
                </Form>
            </div>



        );
    }
}

export default Form.create()(BaseDataForm);