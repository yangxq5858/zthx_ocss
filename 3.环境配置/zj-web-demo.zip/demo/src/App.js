import React from 'react';
import Routers from './configures/routers';

export default class App extends React.Component {
    render() {
        return (
            <Routers/>
        );
    }
}
